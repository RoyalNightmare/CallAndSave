package com.example.call;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button b1,b2,b3,b4,b5,b6,b7,b8,b9,b0,bcall,bsave,bhash,bstar;
    EditText editText;
    StringBuilder sb = new StringBuilder();
    String phoneNumber;
    ImageButton imageButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.button1);
        b2 = findViewById(R.id.button2);
        b3 = findViewById(R.id.button3);
        b4 = findViewById(R.id.button4);
        b5 = findViewById(R.id.button5);
        b6 = findViewById(R.id.button6);
        b7 = findViewById(R.id.button7);
        b8 = findViewById(R.id.button8);
        b9 = findViewById(R.id.button9);
        bhash = findViewById(R.id.button11);
        bstar =findViewById(R.id.button10);
        b0 = findViewById(R.id.button12);
        bsave = findViewById(R.id.button13);
        bcall = findViewById(R.id.button14);
        imageButton = findViewById(R.id.imageButton);
        editText = findViewById(R.id.editTextTextPersonName);
        if(ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(MainActivity.this,new String[]{Manifest.permission.CALL_PHONE},PackageManager.PERMISSION_GRANTED);
        }

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sb.append("1");
                editText.setText(sb.toString());
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sb.append("2");
                editText.setText(sb.toString());
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sb.append("3");
                editText.setText(sb.toString());
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sb.append("4");
                editText.setText(sb.toString());
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sb.append("5");
                editText.setText(sb.toString());
            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sb.append("6");
                editText.setText(sb.toString());
            }
        });
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sb.append("7");
                editText.setText(sb.toString());
            }
        });
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sb.append("8");
                editText.setText(sb.toString());
            }
        });
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sb.append("9");
                editText.setText(sb.toString());
            }
        });
        b0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sb.append("0");
                editText.setText(sb.toString());
            }
        });

        bhash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sb.append("#");
                editText.setText(sb.toString());
            }
        });
        bstar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sb.append("*");
                editText.setText(sb.toString());
            }
        });
        bcall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!validate()){
                    startActivity(new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+ editText.getText().toString())));
                }
            }
        });
        bsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!validate())
                {
                    Intent intent = new Intent(ContactsContract.Intents.Insert.ACTION);
                    intent.setType(ContactsContract.RawContacts.CONTENT_TYPE);
                    intent.putExtra(ContactsContract.Intents.Insert.PHONE,editText.getText().toString());
                    startActivity(intent);
                }
            }
        });
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!validate())
                {
                    sb = new StringBuilder(phoneNumber);
                    if(sb.length()==1)
                    {
                        sb.deleteCharAt(0);
                    }
                    else
                    {
                        sb.deleteCharAt(sb.length()-1);
                    }
                    editText.setText(sb.toString());
                }
            }
        });

    }

    private boolean validate() {
        phoneNumber = editText.getText().toString().trim();
        if(phoneNumber.isEmpty())
        {
            Toast.makeText(MainActivity.this, "Phone number can't be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        else
        {
            editText.setText(phoneNumber);
        }
        return true;
    }
}